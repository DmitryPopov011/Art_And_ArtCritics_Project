﻿// ---------------------------------------------------------------------------------------------------------
// ---- popov 01.03.2021 ----
// ---------------------------------------------------------------------------------------------------------
// Один из служебных классов для передачи параметров в события обмена данными с пользовательским интерфейсом.
// ---------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Art_DataBase_Analytical.Model.Data;

namespace Art_DataBase_Analytical.EventArguments
{
    public class ArtCanvasEventArgs: EventArgs
    {
        private List<IArtCanvasInfo> m_DataList;
        public List<IArtCanvasInfo> DataList
        {
            get { return m_DataList; }
        }

        public ArtCanvasEventArgs(List<IArtCanvasInfo> DL)
        {
            m_DataList = DL;
        }

        public ArtCanvasEventArgs(IArtCanvasInfo obj)
        {
            m_DataList = new List<IArtCanvasInfo> { obj };
        }
    }
}
